%a_10 = round(fir1(10, 3000/2000000)*1024);
%dlmwrite("fir_10_taps.txt", a_10, ' ');
%
%a_30 = round(fir1(30, 3000/2000000)*1024);
%dlmwrite("fir_30_taps.txt", a_30, ' ');
a_30 = fir1(30*256, 3000/2176000);
display(max(a_30));
a_final = round(a_30*32767/max(a_30));
plot(a_final);
dlmwrite("fir_many_taps.txt", a_final, ' ');

%a_60 = round(fir1(60, 3000/2000000)*1024);
%dlmwrite("fir_60_taps.txt", a_60, ' ');